





const UnderDevelopment = () => {
    return (
        <div className="container">
            <h1 className="title">Page Under Development</h1>
            <p className="message">We are working hard to bring you something awesome!</p>
            <div className="loader"></div>
        </div>
    );
};


export default UnderDevelopment