import React from "react";

const PageNotFound=()=>{
    return(
        <div>

        </div>
    )
}

export default PageNotFound