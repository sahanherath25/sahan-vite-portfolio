import React from "react";

const AdminPage=()=>{
    return(
        <section>

            <h1>My Admin PAge</h1>

        </section>
    )
}

export default AdminPage