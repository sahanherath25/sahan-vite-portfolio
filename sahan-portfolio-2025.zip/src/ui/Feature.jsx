
import React from "react";

const Features = () => {
    return (
        <div data-aos="zoom-in">
            <ul>
                <li>Feature 1</li>
                <li>Feature 2</li>
                <li>Feature 3</li>
            </ul>
        </div>
    );
};

export default Features;
