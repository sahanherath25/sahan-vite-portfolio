import AOSInitializer from "../aos/aos.js";
import React, {useEffect} from "react";

const About = () => {

    return (
        <div >
            <p>This is the About section of the website.</p>
        </div>
    );
};

export default About;