import React from "react";




const MainProjects=()=>{
    return(
        <div>

        </div>
    )
}

export default MainProjects